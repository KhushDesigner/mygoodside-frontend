import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import './Onboarding.scss';

// Import assets
import logoIcon from '../../assets/images/logo-icon.svg';

const Onboarding = () => {
    const navigate = useNavigate();

    return (
        <div className="onboardingContainer">
            <div className="onboardingContent">
                <div className="onboardingHeader">
                    <h1 className="onboardingHeader-title">MyGoodSide.Co</h1>
                    <p className="onboardingHeader-subtitle">
                        Each person privately picks their good side, and we bring them all
                        together into one group photo everyone actually loves.
                    </p>
                </div>

                <div className="illustrationWrapper">
                    {/* The logo heads facind opposite ways with stars */}
                    <img src={logoIcon} alt="Heads Logo" className="headsLogo" />

                    {/* Circular people holding hands icon - using a simple SVG markup for predictability */}
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 200 200"
                        className="peopleCircle"
                        fill="none"
                    >
                        {/* A rough representation of people in a circle */}
                        <g fill="currentColor">
                            <circle cx="100" cy="40" r="10" />
                            <circle cx="142" cy="58" r="10" />
                            <circle cx="160" cy="100" r="10" />
                            <circle cx="142" cy="142" r="10" />
                            <circle cx="100" cy="160" r="10" />
                            <circle cx="58" cy="142" r="10" />
                            <circle cx="40" cy="100" r="10" />
                            <circle cx="58" cy="58" r="10" />

                            <path d="M100 50 L125 65 L145 100 L125 135 L100 150 L75 135 L55 100 L75 65 Z" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="5,5" />
                        </g>
                    </svg>
                </div>

                <div className="onboardingActions">
                    <button className="button" onClick={() => navigate('/forgot-password')}>
                        Create a group photo <ArrowRight size={20} />
                    </button>
                    <button className="button button--outline" onClick={() => console.log('Joining group')}>
                        Join via invite link
                    </button>
                </div>

                <p className="onboardingFooterText">
                    The Group Photo, <span>Perfected.</span>
                </p>
            </div>
        </div>
    );
};

export default Onboarding;
