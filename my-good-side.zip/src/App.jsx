import React from 'react';
import AuthHeader from './components/AuthHeader/AuthHeader';
import SignIn from './pages/Sign-in/Sign-in';
import './App.scss';

function App() {
  return (
    <div className="app-wrapper">
      <AuthHeader />

      {/* Background Blobs for the premium effect */}
      <div className="bg-blob blob-1"></div>
      <div className="bg-blob blob-2"></div>
      <div className="bg-blob blob-3"></div>

      <main className="main-content">
        <SignIn />
      </main>
    </div>
  );
}

export default App;
